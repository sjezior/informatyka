#pragma once
#include "karta.h"
#include "Gracz.h"

class Kasyno {
private:
    Karta talia[52];
    int nextIndex;
    Gracz gracze[3];
public:
    Kasyno();
    Karta* dajKarte();
    void graj();
};
