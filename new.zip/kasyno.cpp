#include "karta.h"
#include "kasyno.h"
#include <iostream>

Kasyno::Kasyno()
    : nextIndex(0)
{
    int idx = 0;
    for (int kolor = 0; kolor < 4; ++kolor) {
        for (int wart = 0; wart < 13; ++wart) {
            talia[idx++] = Karta(kolor, wart);
        }
    }
}

Karta* Kasyno::dajKarte() {
    if (nextIndex >= 52) return nullptr;
    return &talia[nextIndex++];
}

void Kasyno::graj() {
    // rozdaj po 2 karty ka�demu (najprostsze podej�cie)
    for (int r = 0; r < 2; ++r) {
        for (int i = 0; i < 3; ++i) {
            gracze[i].wezKarte(dajKarte());
        }
    }

    // poka� r�ce i sumy
    for (int i = 0; i < 3; ++i) {
        std::cout << "Gracz " << (i + 1) << ": ";
        gracze[i].wypiszRekeISume();
    }
}