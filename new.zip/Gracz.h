#pragma once
#include "karta.h"

class Gracz {
private:
    Karta* reke[10];
    int ile;
    int suma;
public:
    Gracz();
    void wezKarte(Karta* _karta);          // umieszcza kart� w r�ce (nic nie robi, gdy pe�na)
    void wypiszRekeISume() const;         // wypisuje karty i sum� punkt�w
    int ileKart() const { return ile; }
    int sumaPunktow() const { return suma; }
};