#include "kasyno.h"

int main() {
    Kasyno moje;
    moje.graj();
    return 0;
}