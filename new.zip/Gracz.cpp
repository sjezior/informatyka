#include "Gracz.h"
#include <iostream>

Gracz::Gracz()
    : ile(0), suma(0)
{
    for (int i = 0; i < 10; ++i) reke[i] = nullptr;
}

void Gracz::wezKarte(Karta* _karta) {
    if (ile >= 10) return;       // najprostsze zabezpieczenie - nie wstawiamy poza tablic�
    reke[ile++] = _karta;
    if (_karta) suma += _karta->getWartosc();
}

void Gracz::wypiszRekeISume() const {
    for (int i = 0; i < ile; ++i) {
        if (reke[i]) reke[i]->wypisz();
        if (i + 1 < ile) std::cout << ' ';
    }
    std::cout << " Suma: " << suma << '\n';
}   